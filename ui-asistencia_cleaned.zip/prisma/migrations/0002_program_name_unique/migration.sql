ALTER TABLE "Program" ADD CONSTRAINT "Program_name_key" UNIQUE ("name");
