// app/admin/loading.tsx
export default function AdminLoading() {
  return (
    <main className="max-w-xl mx-auto p-6">
      <p>Cargando…</p>
    </main>
  );
}
